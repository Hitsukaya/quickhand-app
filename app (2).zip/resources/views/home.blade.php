<x-layouts.app>

<livewire:ad-list />

</x-layouts.app>
