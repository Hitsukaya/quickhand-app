<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>404 Not Found - <?php echo e(config('app.name', 'Laravel')); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>



</head>
<body>

    <div class="flex items-center justify-center min-h-screen bg-gray-100">
        <div class="text-center">
            <h1 class="mb-4 text-4xl font-bold text-red-600">404 | Ooops! Page not found</h1>
            <p class="mb-6">Please return to the home to continue.</p>

            <button  class="px-4 py-2 text-white bg-blue-500 rounded-md hover:bg-blue-600">
                <a href="<?php echo e(route('home')); ?>">Back to Home</a>
            </button>
        </div>
    </div>

</body>
</html>
<?php /**PATH E:\Web Server\xampp\htdocs\mana-de-ajutor\app (2)\resources\views/errors/404.blade.php ENDPATH**/ ?>