<?php if (isset($component)) { $__componentOriginal8a240419d16b3c1a159498153f053ed2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a240419d16b3c1a159498153f053ed2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.main','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.main'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php if(auth()->guard()->check()): ?>
    <?php if (isset($component)) { $__componentOriginal911cf8c0678c340d313de28e034f1caa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal911cf8c0678c340d313de28e034f1caa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.app.auth','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.app.auth'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal911cf8c0678c340d313de28e034f1caa)): ?>
<?php $attributes = $__attributesOriginal911cf8c0678c340d313de28e034f1caa; ?>
<?php unset($__attributesOriginal911cf8c0678c340d313de28e034f1caa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal911cf8c0678c340d313de28e034f1caa)): ?>
<?php $component = $__componentOriginal911cf8c0678c340d313de28e034f1caa; ?>
<?php unset($__componentOriginal911cf8c0678c340d313de28e034f1caa); ?>
<?php endif; ?>
    <?php else: ?>
    <?php if (isset($component)) { $__componentOriginalc95b47459f53c8e215da4638047b0046 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc95b47459f53c8e215da4638047b0046 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.app.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.app.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc95b47459f53c8e215da4638047b0046)): ?>
<?php $attributes = $__attributesOriginalc95b47459f53c8e215da4638047b0046; ?>
<?php unset($__attributesOriginalc95b47459f53c8e215da4638047b0046); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc95b47459f53c8e215da4638047b0046)): ?>
<?php $component = $__componentOriginalc95b47459f53c8e215da4638047b0046; ?>
<?php unset($__componentOriginalc95b47459f53c8e215da4638047b0046); ?>
<?php endif; ?>
    <?php endif; ?>

            <!-- Page Heading -->
            <?php if(isset($header)): ?>
                <header class="bg-white shadow">
                    <div class="px-4 py-2 mx-auto max-w-7xl sm:px-6 lg:px-8">
                        <?php echo e($header); ?>

                    </div>
                </header>
            <?php endif; ?>

            <!-- Page Content -->
            <main>
                <?php echo e($slot); ?>

            </main>
        </div>


    <?php if (isset($component)) { $__componentOriginalca9a174eaf6a8d8aab63294635fe4190 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca9a174eaf6a8d8aab63294635fe4190 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.app.mobile-menu','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.app.mobile-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca9a174eaf6a8d8aab63294635fe4190)): ?>
<?php $attributes = $__attributesOriginalca9a174eaf6a8d8aab63294635fe4190; ?>
<?php unset($__attributesOriginalca9a174eaf6a8d8aab63294635fe4190); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca9a174eaf6a8d8aab63294635fe4190)): ?>
<?php $component = $__componentOriginalca9a174eaf6a8d8aab63294635fe4190; ?>
<?php unset($__componentOriginalca9a174eaf6a8d8aab63294635fe4190); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginale8267c2c5a48486c0c705e5a5d63fd09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale8267c2c5a48486c0c705e5a5d63fd09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.app.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.app.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale8267c2c5a48486c0c705e5a5d63fd09)): ?>
<?php $attributes = $__attributesOriginale8267c2c5a48486c0c705e5a5d63fd09; ?>
<?php unset($__attributesOriginale8267c2c5a48486c0c705e5a5d63fd09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale8267c2c5a48486c0c705e5a5d63fd09)): ?>
<?php $component = $__componentOriginale8267c2c5a48486c0c705e5a5d63fd09; ?>
<?php unset($__componentOriginale8267c2c5a48486c0c705e5a5d63fd09); ?>
<?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a240419d16b3c1a159498153f053ed2)): ?>
<?php $attributes = $__attributesOriginal8a240419d16b3c1a159498153f053ed2; ?>
<?php unset($__attributesOriginal8a240419d16b3c1a159498153f053ed2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a240419d16b3c1a159498153f053ed2)): ?>
<?php $component = $__componentOriginal8a240419d16b3c1a159498153f053ed2; ?>
<?php unset($__componentOriginal8a240419d16b3c1a159498153f053ed2); ?>
<?php endif; ?>
<?php /**PATH E:\Web Server\xampp\htdocs\mana-de-ajutor\app (2)\resources\views/components/layouts/app.blade.php ENDPATH**/ ?>