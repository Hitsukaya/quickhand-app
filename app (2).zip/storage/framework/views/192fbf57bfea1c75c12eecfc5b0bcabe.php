<div class="flex flex-col sm:justify-center items-center pt-2 py-8 sm:pt-0 bg-white">
    <div>
        
    </div>

    <div class="w-full sm:max-w-md  px-6 py-4 mt-6  bg-white shadow-md overflow-hidden sm:rounded-lg">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH E:\Web Server\xampp\htdocs\mana-de-ajutor\app (2)\resources\views/components/authentication-card.blade.php ENDPATH**/ ?>