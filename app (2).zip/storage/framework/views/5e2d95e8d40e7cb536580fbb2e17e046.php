<a
    <?php echo e($attributes->except('wire:navigate')); ?>

    wire:navigate
>
<?php echo e($slot); ?>

</a><?php /**PATH E:\Web Server\xampp\htdocs\mana-de-ajutor\app (2)\resources\views/components/link.blade.php ENDPATH**/ ?>