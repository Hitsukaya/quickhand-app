<?php

namespace App\Filament\Resources\AdApplicationResource\Pages;

use App\Filament\Resources\AdApplicationResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAdApplication extends CreateRecord
{
    protected static string $resource = AdApplicationResource::class;
}
